<?php return array (
  'plugins.reports.subscriptions.displayName' => 'Subscriptions Report',
  'plugins.reports.subscriptions.description' => 'This plugin implements a CSV report containing a list of subscriptions and their info.',
  'plugins.reports.subscriptions.institutionMailingAddress' => 'Institution Mailing Address',
  'plugins.reports.subscriptions.ipRanges' => 'IP Ranges',
); ?>