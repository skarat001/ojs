<?php return array (
  'plugins.citationParser.freecite.displayName' => 'FreeCite Citation Extractor',
  'plugins.citationParser.freecite.description' => 'Extracts fields from plain text citations via the FreeCite service.',
); ?>