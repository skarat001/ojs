<?php return array (
  'plugins.block.information.displayName' => 'Blok Informasi',
  'plugins.block.information.description' => 'Plugin ini menyediakan link informasi.',
  'plugins.block.information.link' => 'Informasi',
); ?>