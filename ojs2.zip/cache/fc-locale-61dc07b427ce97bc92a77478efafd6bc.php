<?php return array (
  'plugins.block.user.displayName' => 'User Block',
  'plugins.block.user.description' => 'This plugin provides sidebar user account tools (e.g. login, logout, profile link, etc).',
  'plugins.block.user.loggedInAs' => 'You are logged in as...',
  'plugins.block.user.myJournals' => 'My Journals',
  'plugins.block.user.myProfile' => 'My Profile',
  'plugins.block.user.logout' => 'Log Out',
  'plugins.block.user.signOutAsUser' => 'Log Out as User',
  'plugins.block.user.rememberMe' => 'Remember me',
  'plugins.block.user.implicitAuthLogin' => 'Journals Login',
); ?>