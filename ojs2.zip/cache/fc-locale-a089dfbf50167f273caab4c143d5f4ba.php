<?php return array (
  'plugins.importexport.doaj.displayName' => 'Plugin Ekspor DOAJ',
  'plugins.importexport.doaj.description' => 'Ekspor Jurnal untuk DOAJ dan sediakan informasi jurnal untuk pencantuman',
  'plugins.importexport.doaj.export' => 'Ekspor Data Jurnal ke DOAJ',
  'plugins.importexport.doaj.export.contact' => 'Kontak DOAJ untuk pencantuman',
  'plugins.importexport.doaj.export.contactInfo' => 'sebagai bahan pertimbangan, silahkan menyerahkan sebagian formulir yang telah diisi ke DOAJ, dan isi informasi yang belum lengkap sebaik yang kamu bisa.',
); ?>