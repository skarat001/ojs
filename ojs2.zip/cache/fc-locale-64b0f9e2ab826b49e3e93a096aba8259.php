<?php return array (
  'plugins.block.subscription.displayName' => 'Subscription Block',
  'plugins.block.subscription.description' => 'This plugin provides sidebar subscription information.',
  'plugins.block.subscription.blockTitle' => 'Subscription',
  'plugins.block.subscription.expires' => 'Expires',
  'plugins.block.subscription.providedBy' => 'Access provided by',
  'plugins.block.subscription.comingFromIP' => 'From',
  'plugins.block.subscription.about' => 'Subscriptions',
  'plugins.block.subscription.loginToVerifySubscription' => 'Login to verify subscription',
); ?>