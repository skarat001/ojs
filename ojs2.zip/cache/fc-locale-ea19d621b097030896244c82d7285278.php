<?php return array (
  'plugins.reports.subscriptions.displayName' => 'Laporan Langganan',
  'plugins.reports.subscriptions.description' => 'Plugin ini menerapkan laporan CSV yang berisi daftar langganan dan info mereka.',
  'plugins.reports.subscriptions.institutionMailingAddress' => 'Alamat surat menyurat Insitusi',
  'plugins.reports.subscriptions.ipRanges' => 'IP Ranges',
); ?>