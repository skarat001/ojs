<?php return array (
  'plugins.block.notification.displayName' => '"Notification" Block',
  'plugins.block.notification.description' => 'This plugin displays information about system notifications.',
); ?>