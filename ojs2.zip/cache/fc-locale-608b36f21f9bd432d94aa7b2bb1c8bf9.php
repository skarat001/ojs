<?php return array (
  'plugins.block.developedBy.displayName' => 'Blok Dibangun Oleh',
  'plugins.block.developedBy.description' => 'Plugin ini menyediakan link Dibangun Oleh.',
); ?>