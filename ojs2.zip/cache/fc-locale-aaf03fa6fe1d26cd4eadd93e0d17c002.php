<?php return array (
  'plugins.generic.googleViewer.name' => 'Google embedded viewer Plugin',
  'plugins.generic.googleViewer.description' => 'This plugin uses the <a href="https://docs.google.com/viewer">Google Docs Viewer</a> service to embed PDFs on the article view page.',
); ?>