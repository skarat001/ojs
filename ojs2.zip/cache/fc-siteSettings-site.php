<?php return array (
  'contactEmail' => 
  array (
    'en_US' => 'admin@gmail.com',
    'id_ID' => 'sein_al@yahoo.com',
  ),
  'contactName' => 
  array (
    'en_US' => 'Open Journal Systems',
    'id_ID' => 'sein',
  ),
  'defaultMetricType' => '',
  'oneStepReset' => false,
  'pageHeaderTitleImage' => 
  array (
    'id_ID' => 
    array (
      'originalFilename' => 'makara-biru.png',
      'width' => 156,
      'height' => 156,
      'uploadName' => 'pageHeaderTitleImage_id_ID.png',
      'dateUploaded' => '2016-06-12 07:48:28',
      'altText' => '',
    ),
  ),
  'pageHeaderTitleType' => 
  array (
    'id_ID' => '1',
  ),
  'preventManagerPluginManagement' => false,
  'showDescription' => true,
  'showThumbnail' => true,
  'showTitle' => true,
  'siteTheme' => '',
  'title' => 
  array (
    'en_US' => 'Open Journal Systems',
    'id_ID' => 'Jurnal Sistem',
  ),
  'useAlphalist' => false,
  'usePaging' => false,
); ?>