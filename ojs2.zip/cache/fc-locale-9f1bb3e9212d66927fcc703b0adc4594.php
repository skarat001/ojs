<?php return array (
  'plugins.OAIMetadata.rfc1807.displayName' => 'RFC1807 Metadata Format',
  'plugins.OAIMetadata.rfc1807.description' => 'Structures metadata in a way that is consistent with the RFC1807 format.',
); ?>