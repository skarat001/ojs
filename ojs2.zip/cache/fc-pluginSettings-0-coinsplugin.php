<?php return array (
  'enabled' => true,
); ?>