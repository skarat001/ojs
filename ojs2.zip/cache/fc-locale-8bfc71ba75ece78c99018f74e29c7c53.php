<?php return array (
  'plugins.block.role.displayName' => 'Role-Specific Block',
  'plugins.block.role.description' => 'This plugin provides a sidebar block containing role-specific information such as submission counts and quick links for Editors, Authors, etc.',
); ?>