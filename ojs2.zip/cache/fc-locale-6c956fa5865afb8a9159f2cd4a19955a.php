<?php return array (
  'plugins.citationFormats.apa.displayName' => 'APA citation format plugin',
  'plugins.citationFormats.apa.citationFormatName' => 'APA',
  'plugins.citationFormats.apa.description' => 'This plugin implements the APA citation format.',
  'plugins.citationFormats.apa.retrieved' => 'Retrieved from <a href="{$url}" target="_new">{$url}</a>',
); ?>