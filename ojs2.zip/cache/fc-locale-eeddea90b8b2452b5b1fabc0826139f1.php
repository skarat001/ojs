<?php return array (
  'plugins.citationFormats.refWorks.displayName' => 'RefWorks citation format plugin',
  'plugins.citationFormats.refWorks.citationFormatName' => 'RefWorks',
  'plugins.citationFormats.refWorks.description' => 'This plugin implements the RefWorks citation format.',
  'plugins.citationFormats.refWorks.export' => 'Export to RefWorks',
); ?>