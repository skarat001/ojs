<?php return array (
  'plugins.generic.roundedcorners.displayName' => 'Rounded Corners',
  'plugins.generic.roundedcorners.description' => 'Plugin ini meletakkan background di tiap sidebar block dan mengelilingi pojokannya. Perubahan dapat dibuat pada warna yang digunakan untuk mengedit CSS stylesheet yang ditemukan di plugin.',
); ?>