<?php return array (
  'plugins.metadata.dc11.articleAdapter.displayName' => 'DC 1.1 Article Adapter',
  'plugins.metadata.dc11.articleAdapter.description' => 'Extracts/injects meta-data from/into articles.',
); ?>