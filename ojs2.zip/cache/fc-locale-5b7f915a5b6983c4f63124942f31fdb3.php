<?php return array (
  'plugins.citationFormats.endNote.displayName' => 'EndNote citation format plugin',
  'plugins.citationFormats.endNote.citationFormatName' => 'EndNote - EndNote format (Macintosh & Windows)',
  'plugins.citationFormats.endNote.description' => 'This plugin implements the EndNote citation format.',
); ?>