<?php return array (
  'acceptGiftSubscriptionPayments' => false,
  'acceptSubscriptionPayments' => true,
  'allowRegAuthor' => true,
  'allowRegReader' => true,
  'allowRegReviewer' => true,
  'authorSelectsEditor' => false,
  'boardEnabled' => true,
  'categories' => NULL,
  'contactEmail' => 'admin@gmail.com',
  'contactFax' => '',
  'contactName' => 'admin',
  'contactPhone' => '',
  'contributors' => 
  array (
  ),
  'copyrightHolderType' => '',
  'copyrightNoticeAgree' => false,
  'copyrightYearBasis' => '',
  'copySubmissionAckAddress' => '',
  'copySubmissionAckPrimaryContact' => false,
  'copySubmissionAckSpecified' => false,
  'currency' => 'USD',
  'disableUserReg' => false,
  'displayCurrentIssue' => true,
  'donationFeeEnabled' => true,
  'emailHeader' => '##default.journalSettings.emailHeader##',
  'emailSignature' => '________________________________________________________________________
jurbal baru
http://localhost/ojs2/ojs2/index.php/jurnal',
  'enableAnnouncements' => true,
  'enableAnnouncementsHomepage' => true,
  'enableComments' => 0,
  'enableLockss' => false,
  'enablePageNumber' => true,
  'enablePublicArticleId' => false,
  'enablePublicGalleyId' => false,
  'enablePublicIssueId' => false,
  'enablePublicSuppFileId' => false,
  'envelopeSender' => '',
  'fastTrackFee' => 20,
  'fastTrackFeeEnabled' => true,
  'includeCopyrightStatement' => false,
  'includeLicense' => false,
  'initialNumber' => 0,
  'initialVolume' => 0,
  'initialYear' => 0,
  'issuePerVolume' => 0,
  'itemsPerPage' => 25,
  'journalPaymentsEnabled' => true,
  'journalTheme' => '',
  'licenseURL' => '',
  'mailingAddress' => '',
  'mailSubmissionsToReviewers' => false,
  'membershipFee' => 0,
  'membershipFeeEnabled' => true,
  'metaCitationOutputFilterId' => -1,
  'metaCitations' => true,
  'metaCoverage' => false,
  'metaDiscipline' => true,
  'metaSubject' => false,
  'metaSubjectClass' => false,
  'metaType' => false,
  'notifyAllAuthorsOnDecision' => false,
  'numAnnouncementsHomepage' => 10,
  'numDaysBeforeInviteReminder' => 0,
  'numDaysBeforeSubmitReminder' => 0,
  'numPageLinks' => 10,
  'numWeeksPerReview' => 4,
  'onlineIssn' => '123123',
  'paymentMethodPluginName' => 'ManualPayment',
  'printIssn' => '123123',
  'provideRefLinkInstructions' => true,
  'publicationFee' => 5,
  'publicationFeeEnabled' => true,
  'publicationFormatNumber' => true,
  'publicationFormatTitle' => true,
  'publicationFormatVolume' => true,
  'publicationFormatYear' => true,
  'publisherInstitution' => '',
  'publisherUrl' => '',
  'publishingMode' => 0,
  'purchaseArticleFee' => 5,
  'purchaseArticleFeeEnabled' => true,
  'purchaseIssueFee' => 1,
  'purchaseIssueFeeEnabled' => true,
  'rateReviewerOnQuality' => false,
  'remindForInvite' => false,
  'remindForSubmit' => false,
  'requireAuthorCompetingInterests' => false,
  'requireReviewerCompetingInterests' => false,
  'restrictArticleAccess' => false,
  'restrictOnlyPdf' => false,
  'restrictReviewerFileAccess' => false,
  'restrictSiteAccess' => false,
  'reviewerAccessKeysEnabled' => false,
  'reviewerDatabaseLinks' => 
  array (
    0 => 
    array (
      'title' => '',
      'url' => '',
    ),
  ),
  'rtAbstract' => true,
  'rtAddComment' => true,
  'rtCaptureCite' => true,
  'rtDefineTerms' => true,
  'rtEmailAuthor' => true,
  'rtEmailOthers' => true,
  'rtEnabled' => true,
  'rtFindingReferences' => false,
  'rtPrinterFriendly' => true,
  'rtSharingBrand' => '',
  'rtSharingButtonStyle' => '',
  'rtSharingDropDown' => '',
  'rtSharingDropDownMenu' => '',
  'rtSharingEnabled' => '',
  'rtSharingLanguage' => '',
  'rtSharingLogo' => '',
  'rtSharingLogoBackground' => '',
  'rtSharingLogoColor' => '',
  'rtSharingUserName' => '',
  'rtSupplementaryFiles' => true,
  'rtVersionId' => 0,
  'rtViewMetadata' => true,
  'rtViewReviewPolicy' => true,
  'showEnsuringLink' => false,
  'showGalleyLinks' => false,
  'sponsors' => 
  array (
  ),
  'submissionFee' => 10,
  'submissionFeeEnabled' => true,
  'supportedFormLocales' => 
  array (
    0 => 'id_ID',
  ),
  'supportedLocales' => 
  array (
    0 => 'en_US',
    1 => 'id_ID',
  ),
  'supportedSubmissionLocales' => 
  array (
    0 => 'id_ID',
  ),
  'supportEmail' => 'admin@gmail.com',
  'supportName' => 'admin',
  'supportPhone' => '',
  'useCopyeditors' => false,
  'useEditorialBoard' => false,
  'useLayoutEditors' => false,
  'useProofreaders' => false,
  'volumePerYear' => 0,
  'authorGuidelines' => 
  array (
    'id_ID' => 'ptjk penls',
  ),
  'authorInformation' => 
  array (
    'id_ID' => 'Tertarik menerbitkan jurnal? Kami merekomendasikan Anda mereview halaman <a href="/ojs2/ojs2/index.php/jurnal/about"> Tentang Kami </a> untuk kebijakan bagian jurnal serta <a href="/ojs2/ojs2/index.php/jurnal/about/submissions#authorGuidelines"> Petunjuk Penulis </a>. Penulis perlu <a href="/ojs2/ojs2/index.php/jurnal/user/register"> Mendaftar </a> dengan jurnal sebelum menyerahkan atau jika sudah terdaftar <a href="/ojs2/ojs2/index.php/index/login">login</a> dan mulai proses lima langkah.',
  ),
  'authorSelfArchivePolicy' => 
  array (
    'id_ID' => 'Jurnal ini memberi izin dan mendorong penulis untuk memposting item yang diserahkan ke jurnal di website personal atau repositori institusional sebelum dan sesudah penerbitan, sementara itu menyediakan detail bibliografi yang akan memberikan kredit, jika bisa diterapkan, penerbitannya di jurnal ini.',
  ),
  'copyeditInstructions' => 
  array (
    'id_ID' => 'Tahap Copyediting dimaksudkan untuk meningkatkan aliran, kejelasan, tata bahasa, kata-kata, dan pemformatan artikel. Tahap ini mewakili kesempatan terakhir untuk penulis untu membuat perubahan substansial apapun pada teks karena tahap selanjutnya terlarang untuk koreksi format dan kesalahan penulisan. File untuk dicopyedit ada dalam format word atau .rtf dan maka dari itu bisa diedit dengan mudah sebagai dokumen yang diproses menggunakan word. Satu set instruksi yang ditampilkan di sini mengusulkan dua pendekatan untuk copyediting. Satu berdasarkan fitur Perubahan Alur Microsoft Word dan meminta copy editor, editor dan penulis memiliki akses ke program ini. Sistem kedua, yang perangkat lunak independent dikembangkan oleh pengembang tanpa terikat pihak manapun, telah meminjam tanpa permisi, dari Review Pendidikan Harvard. Editor Jurnal bisa memodifikasi instruksi ini, jadi saran bisa dibuat untuk meningkatkan proses jurnal ini.<h4>Sistem Copyedit</h4><strong>1. Perubahan Alur Microsoft Word</strong> Di bawah Alat di menu bar, fitur Perubahan Alur memungkinkan Copyedit untuk membuat sisipan (teks diberi warna) dan penghapusan (teks diberi coretan dengan warna atau di margin dan ditandai dengan kata dihapus). Copy editor dapat menempatkan pertanyaan pada penulis (Pertanyaan Penulis) dan pada editor (Pertanyaan Editor) dnegan menyisipkan pertanyaan-pertanyaan di dalam tanda kurung besar. Versi yang sudah dicopyedit kemudian diunggah, dan editor diberitahu. Editor kemudian mereview teks dan memberitahu penulis. Editor dan penulis harus membuat perubahan yang terbaik. Jika perubahan selanjutnya dianggap perlu, editor dan penulis dapat membuat perubahan ke penyisipan awal dan penghapusan, serta penyisipan dan penghapusan dimanapun di teks. Penulis dan editor harus merespon kepada masing-masing pertanyaan yang ditujukan kepada mereka, dengan respon ditempatkan di dalam tanda kurung besar. Setelah teks telah direview oleh editor dan penulis, copy editor akan melakukan pengecekan terakhir untuk tahap layout dan galley. <strong>2. Review Pendidikan Harvard </strong> <strong> Instruksi untuk Membuat Revisi Elektronik untuk Manuskrip </strong> Ikuti protokol untuk membuat revisi elekronik untuk manuskrip Anda: <strong> Merespon Perubahan yang Disarankan.</strong>   Untuk masing-masing perubahan yang disarankan yang Anda terima, teks tidak ditebalkan.   Untuk masing-masing perubahan yang disarankan yang Anda tidak terima, masukkan kembali teks asli dan <strong> tebalkan </strong> <strong> Membuat tambahan penghapusan.</strong>   Tunjukkan tambahan dengan <strong> menebalkan </strong> teks baru.   Gantikan bagian yang dihapus dengan: <strong>[hapus teks]</strong>.   Jika Anda menghapus satu atau lebih kalimat, tunjukkan dengan sebuah catatan, contoh <strong>[hapus 2 kalimat]</strong>. <strong> Merespon pertanyaan untuk Penulis.</strong>   Menyimpan semua pertanyaan untuk penulis tetap utuh dan menebalkan teks.   Untuk menjawab pertanyaan untuk penulis, tambahkan sebuah komentar setelahnya. Komentar harus dibatasi dengan menggunakan: <strong>[Komentar:]</strong>   contoh: <strong>[Komentar: diskusi metodologi yang berkembang seperti yang Anda sarankan]</strong>. <strong> Membuat Komentar.</strong>   Gunakan komentar untuk menjelaskan perubahan organisasional atau revisi utama   contoh: <strong>[Komentar: Pindah paragraf di atas dari hal. 5 ke hal. 7].</strong>  Catatan: Saat mengacu ke nomor halaman, gunakan nomor halaman dari print salinan manuskrip yang telah dikirimkan ke Anda. Hal ini penting karena nomor halaman bisa berubah saat dokumen direvisi secara elektronik.<h4>Ilustrasi Revisi Elektronik</h4><ol><li><strong> Copyedit awal </strong> Copy editor jurnal akan mengedit teks untuk meningkatkan aliran, kejelasan, tata bahasa, kata-kata dan pemformatan, juga termasuk pertanyaan penulis jika perlu. Saat edit awal selesai, copy editor akan mengunggah dokumen yang sudah direvisi melalui Web site jurnal dan memberitahu penulis bahwa manuskrip tersedia untuk review.</li><li><strong> Copyedit Penulis.</strong> Sebelum mengecek struktur dan organisasi manuskrip yang sudah diedit, penulis harus mengecek dengan editor yang menangani naskah itu. Penulis harus menerima/ menolak perubahan apapun yang dibuat selama awal copyediting, jika tepat, dan merespon ke semua pertanyaan penulis. Saat selesai dengan revisi, penulis harus menamai ulang file dari nama penulisQA.doc menjadi NamaPenulisQAR.doc (contoh: dari LeeQA.doc ke LeeQAR.doc) dan mengunggah dokumen yang telah direvisi melalui website jurnal seperti yang diarahkan.</li><li><strong> Copyedit akhir.</strong>Copy editor jurnal akan memverifikasi perubahan yang dibuat oleh penulis dan menggabungkan respon pada pertanyaan penulis untuk membuat manuskrip final. Saat selesai, copy editor akan mengunggah dokumen final melalui web site jurnal dan mengingatkan editor layout untuk menyelesaikan pemformatan.</li></ol>',
  ),
  'customAboutItems' => 
  array (
    'id_ID' => 
    array (
      0 => 
      array (
        'title' => '',
        'content' => '',
      ),
    ),
  ),
  'description' => 
  array (
    'id_ID' => 'Selamat datang di jurnal baru',
  ),
  'donationFeeDescription' => 
  array (
    'id_ID' => 'Donasi berapa pun jumlahnya untuk jurnal ini sangat diterima karena membantu dan menyediakan sarana bagi editor untuk menyediakan jurnal dengan kualitas terbaik untuk para pembaca.',
  ),
  'donationFeeName' => 
  array (
    'id_ID' => 'Donasi untuk jurnal',
  ),
  'fastTrackFeeDescription' => 
  array (
    'id_ID' => 'Dengan pembayaran biaya ini, review, keputusan editorial, dan notifikasi penulis di manuskrip ini dijamin dalam 4 minggu.',
  ),
  'fastTrackFeeName' => 
  array (
    'id_ID' => 'Fast-Track Review',
  ),
  'focusScopeDesc' => 
  array (
    'id_ID' => 'fkus n rung lnkp jrnl',
  ),
  'homeHeaderLogoImage' => 
  array (
    'id_ID' => 
    array (
      'name' => 'homeHeaderTitleImage_id_ID.png',
      'uploadName' => 'homeHeaderLogoImage_id_ID.png',
      'width' => 156,
      'height' => 156,
      'mimeType' => 'image/png',
      'dateUploaded' => '2016-06-15 04:36:44',
    ),
  ),
  'homeHeaderTitle' => 
  array (
    'id_ID' => 'jurnalku',
  ),
  'homeHeaderTitleImageAltText' => 
  array (
    'id_ID' => 'jurnalku',
  ),
  'initials' => 
  array (
    'id_ID' => 'jb',
  ),
  'journalFavicon' => 
  array (
    'id_ID' => 
    array (
      'name' => 'homeHeaderLogoImage_id_ID.png',
      'uploadName' => 'journalFavicon_id_ID.png',
      'width' => 156,
      'height' => 156,
      'mimeType' => 'image/png',
      'dateUploaded' => '2016-06-15 05:08:29',
    ),
  ),
  'journalPageFooter' => 
  array (
    'id_ID' => 'Copyright Gamma Teknologi Indonesia 2016',
  ),
  'librarianInformation' => 
  array (
    'id_ID' => 'Kami mendorong pustakawan riset untuk mendaftar jurnal diantara pemegang jurnal eletronik perpustakaan. Begitu juga, ini mungkin berharga bahwa sistem penerbitan sumber terbuka jurnal cocok untuk perpustakaan untuk menjadi tuan rumah untuk anggota fakultas untuk menggunakan jurnal saat mereka terlibat dalam proses editing. (Lihat <a href="http://pkp.sfu.ca/ojs">Open Journal Systems</a>).',
  ),
  'lockssLicense' => 
  array (
    'id_ID' => 'OJS sistem LOCKSS berfungsi sebagai sistem pengarsipan terdistribusi antar-perpustakaan yang menggunakan sistem ini dengan tujuan membuat arsip permanen (untuk preservasi dan restorasi). <a href="http://www.lockss.org/">Lanjut...</a>',
  ),
  'membershipFeeDescription' => 
  array (
    'id_ID' => 'Pembayaran biaya ini akan mendaftarkan Anda sebagai anggota di asosiasi ini untuk satu tahun dan memberikan akses gratis ke jurnal ini.',
  ),
  'membershipFeeName' => 
  array (
    'id_ID' => 'Keanggotaan Asosiasi',
  ),
  'metaDisciplineExamples' => 
  array (
    'id_ID' => 'History; Education; Sociology; Psychology; Cultural Studies; Law',
  ),
  'metaSubjectExamples' => 
  array (
    'id_ID' => 'Photosynthesis; Black Holes; Four-Color Map Problem; Bayesian Theory',
  ),
  'navItems' => 
  array (
    'id_ID' => 
    array (
      0 => 
      array (
        'name' => '',
        'url' => '',
      ),
    ),
  ),
  'openAccessPolicy' => 
  array (
    'id_ID' => 'Jurnal ini menyediakan akses terbuka yang pada prinsipnya membuat riset tersedia secara gratis untuk publik dan akan mensupport pertukaran pengetahuan global terbesar.',
  ),
  'pageHeaderTitleImage' => 
  array (
    'id_ID' => 
    array (
      'name' => 'homeHeaderLogoImage_id_ID.png',
      'uploadName' => 'pageHeaderTitleImage_id_ID.png',
      'width' => 156,
      'height' => 156,
      'mimeType' => 'image/png',
      'dateUploaded' => '2016-06-15 05:07:04',
    ),
  ),
  'pageHeaderTitleType' => 
  array (
    'id_ID' => '1',
  ),
  'privacyStatement' => 
  array (
    'id_ID' => 'Nama dan alamat email yang dimasukkan di situs jurnal hanya akan digunakan untuk tujuan yang sudah disebutkan, tidak akan disalahgunakan untuk tujuan lain atau untuk pihak lain.',
  ),
  'proofInstructions' => 
  array (
    'id_ID' => '<p>Tahap proofreading dimaksudkan untuk menemukan kesalahan di format, tata bahasa, ejaan galley. Perubahan yang lebih penting tidak bisa dibuat di tahap ini, kecuali didiskusikan dengan Editor bagian. Di layout, klik di VIEW PROOF untuk melihat HTML, PDF, dan format file lain yang tersedia dalam menerbitkan item ini.</p><h4>Untuk kesalahan tata bahasa dan ejaan</h4><p>Salin kata atau sekelompok kata yang menjadi masalah dan letakkan mereka di kotak Proofreading Corrections dengan instruksi "UBAH_KE" untuk editor seperti berikut ini:</p><pre>1. UBAH...
	kemudian yang lain
	Ke...
	Dibanding yang lain</pre><br /><pre>2. UBAH...
	Malinowsky 
	KE....
	Malinowski</pre><br /><h4>Untuk kesalahan pemformatan</h4><p>Gambarkan lokasi dan asal masalah dalam kotak Proofreading Corrections setelah mengetik judul "PEMFORMATAN" seperti berikut ini:</p><br /><pre>3. PEMFORMATAN
	Nomor dalam table 3 tidak diluruskan di kolom ketiga.</pre><br /><pre>4. PEMFORMATAN
	Paragraf yang dimulai dengan "Topik terakhir ini…" tidak indented.</pre>',
  ),
  'publicationFeeDescription' => 
  array (
    'id_ID' => 'Jika naskah ini diterbitkan, Anda akan dikenakan penerbitan artikel.',
  ),
  'publicationFeeName' => 
  array (
    'id_ID' => 'Penerbitan artikel',
  ),
  'purchaseArticleFeeDescription' => 
  array (
    'id_ID' => 'Pembayaran biaya ini akan memudahkan Anda untuk melihat, mengunduh, dan menge-print artikel ini.',
  ),
  'purchaseArticleFeeName' => 
  array (
    'id_ID' => 'Membeli Artikel',
  ),
  'purchaseIssueFeeName' => 
  array (
    'id_ID' => 'subscribe',
  ),
  'readerInformation' => 
  array (
    'id_ID' => 'Kami mendorong pembaca untuk sign up untuk pelayanan notifikasi penerbitan untuk jurnal ini. Gunakan tautan <a href="/ojs2/ojs2/index.php/jurnal/user/register">Daftar</a> di bagian atas home page untuk jurnal. Pendaftaran ini akan berakibat pembaca mendapatkan Daftar Isi oleh email untuk tiap terbitan jurnal baru. Daftar ini juga memudahkan jurnal untuk mengklaim level tertentu dukungan atau jumlah pembaca. Lihat jurnal <a href="/ojs2/ojs2/index.php/jurnal/about/submissions#privacyStatement"> Pernyataan Pribadi </a>, yang meyakinkan pembaca bahwa nama mereka dan alamat email tidak akan digunakan untuk tujuan lain.',
  ),
  'refLinkInstructions' => 
  array (
    'id_ID' => '<h4>Untuk menambah tautaning acuan ke proses layout</h4><p>Saat mengubah naskah menjadi HTML atau PDF, pastikan semua hyperlink dalam naskah aktif.</p><h4>A. Saat penulis menyediakan tautan dengan acuan</h4><ol><li>Sementara naskah masih dalam format word-processing (contoh: word), tambahkan frase LIHAT ITEM sampai akhir acuan yang mempunyai URL.</li><li>Ubah frase ke hyperlink dengan meng-highlightnya dan menggunakan alat Insert Hyperlink milik Word dan URL yang disiapkan di #2.</li></ol><h4>B. Memudahkan pembaca ke Search Google Scholar untuk referensi</h4><ol><li>Saat naskah masih dalam format word-processing (contoh: word), salin judul naskah yang dijadikan acuan di daftar referensi (jika ditampilkan terlalu biasa sebagai judul-contoh: "Damai"-kemudian salin penulis dan judul).</li><li>salin judul referensi antara %22\'s, tempatkan a + diantara kata: http://scholar.google.com/scholar?q=%22PASTE+TITLE+HERE%22&amp;hl=en&amp;lr=&amp;btnG=Search.</li><li>Tambahkan frase GS SEARCH sampai akhir masing-masing Sitiran di daftar referensi naskah.</li><li>Ubah frase itu ke hyperlink dengan meng-highlightnya danmenggunakan alat Insert Hyperlink milik Word dan URL yang disiapkan di #2.</li></ol><h4>C. Memudahkan pembaca untuk mencari referensi dengan DOI</h4><ol><li>Sementara naskah masih di Word, salin sekelompok referensi ke dalam CrossRef Text Query http://www.crossref.org/freeTextQuery/.</li><li>Salin tiap DOI yang disediakan pertanyaan di URL berikut ini (diantara = and &amp;): http://www.cmaj.ca/cgi/external_ref?access_num=PASTE DOI#HERE&amp;link_type=DOI.</li><li>Tambahkan frase CrossRef hingga akhir tiap Sitiran di daftar referensi naskah.</li><li>Ubah frase menjadi hyperlink dengan meng-highlight frase dan menggunakan alat Insert Hyperlink Word dan URL yang disediakan dan tepat di #2.</li></ol>',
  ),
  'reviewGuidelines' => 
  array (
    'id_ID' => 'ptjk revw',
  ),
  'reviewPolicy' => 
  array (
    'id_ID' => 'per rvw',
  ),
  'submissionChecklist' => 
  array (
    'id_ID' => 
    array (
      0 => 
      array (
        'order' => '1',
        'content' => 'Penyerahan belum diterbitkan sebelumnya, atau sedang dalam pertimbangan jurnal lain (atau sebuah penjelasan belum disediakan dalam komentar kepada editor).',
      ),
      1 => 
      array (
        'order' => '2',
        'content' => 'File naskah dalam format file dokumen OpenOffice, Microsoft Word, RTF, atau WordPerfect.',
      ),
      2 => 
      array (
        'order' => '3',
        'content' => 'Ketika tersedia, URLs untuk referensi telah disediakan.',
      ),
      3 => 
      array (
        'order' => '4',
        'content' => 'Teks 1 spasi; font 12; italic; tidak digaribawahi (kecuali alamat URL); dan semua ilustrasi, figur, dan tabel yang ditempatkan di dalam teks pada poin yang tepat, jangan di akhir.',
      ),
      4 => 
      array (
        'order' => '5',
        'content' => 'Teks yang mematuhi persyaratan mengenai perpustakaan dan gaya bahasa digambarkan secara garis besar di <a href="/ojs2/ojs2/index.php/jurnal/about/submissions#authorGuidelines" target="_new">Petunjuk Penulis</a>, yang akan ditemukan dalam halaman Tentang Kami.',
      ),
      5 => 
      array (
        'order' => '6',
        'content' => 'Jika penerimaan untuk bagian peer-review dari jurnal, instruksinya terdapat di <a href="javascript:openHelp(\'http://localhost/ojs2/ojs2/index.php/jurnal/help/view/editorial/topic/000044\')"> Memastikan Reviewer Anonim </a> telah diikuti.',
      ),
    ),
  ),
  'submissionFeeDescription' => 
  array (
    'id_ID' => 'Penulis diminta untuk membayar biaya penyerahan artikel sebagai bagian dari proses penyerahan untuk berkontribusi pada biaya review.',
  ),
  'submissionFeeName' => 
  array (
    'id_ID' => 'Penyerahan artikel',
  ),
  'title' => 
  array (
    'id_ID' => 'jurnal baru',
  ),
  'waiverPolicy' => 
  array (
    'id_ID' => 'Jika Anda tidak mempunyai dana untuk membayar biaya penerbitan, kami akan membebaskan Anda dari biaya apapun. Kami tidak ingin biaya menghambat penerbitan karya yang berharga.',
  ),
); ?>