<?php return array (
  'plugins.generic.coins.displayName' => 'COinS Plugin',
  'plugins.generic.coins.description' => 'The COinS plugin adds an OpenURL descriptor to article pages (abstract and HTML) that can be used e.g. for extraction to citation tools.',
); ?>