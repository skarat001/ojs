<?php return array (
  'plugins.metadata.dc11.displayName' => 'Dublin Core 1.1 meta-data',
  'plugins.metadata.dc11.description' => 'Contributes Dublin Core version 1.1 schemas and application adapters.',
); ?>