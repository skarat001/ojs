<?php return array (
  'plugins.citationLookup.pubmed.displayName' => 'PubMed Database Connector',
  'plugins.citationLookup.pubmed.description' => 'Connects to the PubMed bibliographic database.',
); ?>