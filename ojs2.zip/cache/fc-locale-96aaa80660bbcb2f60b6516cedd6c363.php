<?php return array (
  'plugins.block.help.displayName' => 'Help Block',
  'plugins.block.help.description' => 'This plugin provides sidebar help link.',
); ?>