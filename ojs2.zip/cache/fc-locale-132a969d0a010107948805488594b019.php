<?php return array (
  'plugins.metadata.mods34.displayName' => 'MODS 3.4 meta-data',
  'plugins.metadata.mods34.description' => 'Contributes MODS 3.4 schemas and application adapters.',
  'plugins.metadata.mods34.mods34XmlOutput.displayName' => 'MODS 3.4 Output',
  'plugins.metadata.mods34.mods34XmlOutput.description' => 'Convert a MODS 3.4 meta-data description to its XML binding.',
); ?>