<?php return array (
  'enabled' => true,
  'exclusions' => '#^http://www.google.#
#^http://www.yahoo.#',
); ?>