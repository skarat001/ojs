<?php return array (
  'plugins.reports.articles.displayName' => 'Laporan Artikel',
  'plugins.reports.articles.description' => 'Plugin ini menerapkan laporan CSV yang berisi daftar artikel dan info mereka.',
  'plugins.reports.articles.nodecision' => 'Tidak ada keputusan',
); ?>