<?php return array (
  'plugins.generic.sehl.name' => 'Plugin SEHL',
  'plugins.generic.sehl.description' => 'Plugin ini mengimplementasikan Search Engine HighLighting (SEHL) sehingga saat mesin pencari meletakkan artikel HTML, kata kunci yang dikehendaki disoroti.',
); ?>