<?php return array (
  'plugins.theme.custom.name' => 'Tema Common',
  'plugins.theme.custom.description' => 'Plugin ini menerapkan penyesuain tema.',
  'plugins.theme.custom.notWritable' => 'Catatan: file pugin stylesheet ini, "{$stylesheetFileLocation}", saat ini tidak dapat ditulis. File ini harus dapat ditulis sebelum plugin dapat digunakan.',
  'plugins.theme.custom.settings' => 'Penagturan',
  'plugins.theme.custom.pickColour' => 'Pilih Warna',
  'plugins.theme.custom.header' => 'Header',
  'plugins.theme.custom.link' => 'Link',
  'plugins.theme.custom.background' => 'Background',
  'plugins.theme.custom.foreground' => 'Foreground',
); ?>