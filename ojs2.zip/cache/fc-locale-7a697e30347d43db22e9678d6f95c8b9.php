<?php return array (
  'plugins.block.languageToggle.displayName' => 'Blok Pengaturan Bahasa',
  'plugins.block.languageToggle.description' => 'Plugin ini menyediakan pengaturan bahasa.',
  'plugins.block.languageToggle.selectLabel' => 'Pilih bahasa',
); ?>