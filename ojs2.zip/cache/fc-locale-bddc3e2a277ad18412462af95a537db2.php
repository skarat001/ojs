<?php return array (
  'plugins.block.readingTools.displayName' => 'Blok Alat Membaca',
  'plugins.block.readingTools.description' => 'Plugin ini menampilkan blok yang berisi alat membaca dalam bagian alat membaca.',
  'plugins.block.readingTools.title' => 'Alat Membaca',
  'plugins.block.readingTools.aboutTheAuthor' => 'Tentang Penulis',
  'plugins.block.readingTools.aboutTheAuthors' => 'Tentang Penulis',
  'plugins.block.readingTools.articleTools' => 'Alat Artikel',
  'plugins.block.readingTools.emailThisArticle' => 'Email Artikel ini',
  'plugins.block.readingTools.loginRequired' => 'Login dibutuhkan',
  'plugins.block.readingTools.printThisArticle' => 'Cetak Artikel ini',
  'plugins.block.readingTools.postComment' => 'Kirim Komentar',
); ?>