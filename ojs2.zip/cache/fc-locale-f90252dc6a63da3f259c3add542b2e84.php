<?php return array (
  'plugins.block.developedBy.displayName' => '"Developed By" Block',
  'plugins.block.developedBy.description' => 'This plugin provides sidebar "Developed By" link.',
); ?>