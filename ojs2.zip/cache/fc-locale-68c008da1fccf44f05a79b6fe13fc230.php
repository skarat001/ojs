<?php return array (
  'plugins.citationParser.regex.displayName' => 'Regular Expressions Citation Extractor',
  'plugins.citationParser.regex.description' => 'Extracts fields from plain text citations via regular expressions.',
); ?>