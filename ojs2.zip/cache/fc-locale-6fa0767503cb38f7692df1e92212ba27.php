<?php return array (
  'plugins.citationOutput.abnt.displayName' => 'ABNT Citation Style',
  'plugins.citationOutput.abnt.description' => 'Implements the ABNT citation style.',
); ?>