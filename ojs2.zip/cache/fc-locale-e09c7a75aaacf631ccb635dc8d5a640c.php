<?php return array (
  'plugins.citationLookup.worldcat.displayName' => 'WorldCat Database Connector',
  'plugins.citationLookup.worldcat.description' => 'Connects to the WorldCat bibliographic database.',
); ?>