<?php return array (
  'plugins.generic.coins.displayName' => 'COinS Plugin',
  'plugins.generic.coins.description' => 'Plugin CoinS menambahkan deskriptor OpenURL ke halaman artikel (abstrak dan HTML) yang dapat digunakan contohnya untuk ekstrasi ke alat kutipan.',
); ?>