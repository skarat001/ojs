<?php return array (
  'plugins.block.subscription.displayName' => 'Blok Langganan',
  'plugins.block.subscription.description' => 'Plugin ini menyediakan informasi langganan.',
  'plugins.block.subscription.blockTitle' => 'Langganan',
  'plugins.block.subscription.expires' => 'Kadaluwarsa',
  'plugins.block.subscription.providedBy' => 'Akses disediakan oleh',
  'plugins.block.subscription.comingFromIP' => 'Dari',
  'plugins.block.subscription.about' => 'Langganan',
  'plugins.block.subscription.loginToVerifySubscription' => 'Login untuk memverifikasi langganan',
); ?>