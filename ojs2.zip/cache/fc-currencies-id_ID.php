<?php return array (
  'AFN' => 
  array (
    0 => 'Afghani',
    1 => '971',
  ),
  'DZD' => 
  array (
    0 => 'Algerian dinar',
    1 => '012',
  ),
  'ARS' => 
  array (
    0 => 'Argentine peso',
    1 => '032',
  ),
  'AMD' => 
  array (
    0 => 'Armenian dram',
    1 => '051',
  ),
  'AWG' => 
  array (
    0 => 'Aruban guilder',
    1 => '533',
  ),
  'AUD' => 
  array (
    0 => 'Australian dollar',
    1 => '036',
  ),
  'AZN' => 
  array (
    0 => 'Azerbaijanian manat',
    1 => '944',
  ),
  'BSD' => 
  array (
    0 => 'Bahamian dollar',
    1 => '044',
  ),
  'BHD' => 
  array (
    0 => 'Bahraini dinar',
    1 => '048',
  ),
  'THB' => 
  array (
    0 => 'Baht',
    1 => '764',
  ),
  'PAB' => 
  array (
    0 => 'Balboa',
    1 => '590',
  ),
  'BDT' => 
  array (
    0 => 'Bangladeshi taka',
    1 => '050',
  ),
  'BBD' => 
  array (
    0 => 'Barbados dollar',
    1 => '052',
  ),
  'BYR' => 
  array (
    0 => 'Belarussian ruble',
    1 => '974',
  ),
  'BZD' => 
  array (
    0 => 'Belize dollar',
    1 => '084',
  ),
  'BMD' => 
  array (
    0 => 'Bermudian dollar (customarily known as Bermuda dollar)',
    1 => '060',
  ),
  'BOV' => 
  array (
    0 => 'Bolivian Mvdol (funds code)',
    1 => '984',
  ),
  'BOB' => 
  array (
    0 => 'Boliviano',
    1 => '068',
  ),
  'BRL' => 
  array (
    0 => 'Brazilian real',
    1 => '986',
  ),
  'BND' => 
  array (
    0 => 'Brunei dollar',
    1 => '096',
  ),
  'BGN' => 
  array (
    0 => 'Bulgarian lev',
    1 => '975',
  ),
  'BIF' => 
  array (
    0 => 'Burundian franc',
    1 => '108',
  ),
  'XOF' => 
  array (
    0 => 'CFA Franc BCEAO',
    1 => '952',
  ),
  'XAF' => 
  array (
    0 => 'CFA franc BEAC',
    1 => '950',
  ),
  'XPF' => 
  array (
    0 => 'CFP franc',
    1 => '953',
  ),
  'CAD' => 
  array (
    0 => 'Canadian dollar',
    1 => '124',
  ),
  'CVE' => 
  array (
    0 => 'Cape Verde escudo',
    1 => '132',
  ),
  'KYD' => 
  array (
    0 => 'Cayman Islands dollar',
    1 => '136',
  ),
  'GHS' => 
  array (
    0 => 'Cedi',
    1 => '936',
  ),
  'CLP' => 
  array (
    0 => 'Chilean peso',
    1 => '152',
  ),
  'COP' => 
  array (
    0 => 'Colombian peso',
    1 => '170',
  ),
  'KMF' => 
  array (
    0 => 'Comoro franc',
    1 => '174',
  ),
  'BAM' => 
  array (
    0 => 'Convertible marks',
    1 => '977',
  ),
  'NIO' => 
  array (
    0 => 'Cordoba oro',
    1 => '558',
  ),
  'CRC' => 
  array (
    0 => 'Costa Rican colon',
    1 => '188',
  ),
  'HRK' => 
  array (
    0 => 'Croatian kuna',
    1 => '191',
  ),
  'CUP' => 
  array (
    0 => 'Cuban peso',
    1 => '192',
  ),
  'CZK' => 
  array (
    0 => 'Czech koruna',
    1 => '203',
  ),
  'GMD' => 
  array (
    0 => 'Dalasi',
    1 => '270',
  ),
  'DKK' => 
  array (
    0 => 'Danish krone',
    1 => '208',
  ),
  'MKD' => 
  array (
    0 => 'Denar',
    1 => '807',
  ),
  'DJF' => 
  array (
    0 => 'Djibouti franc',
    1 => '262',
  ),
  'STD' => 
  array (
    0 => 'Dobra',
    1 => '678',
  ),
  'DOP' => 
  array (
    0 => 'Dominican peso',
    1 => '214',
  ),
  'XCD' => 
  array (
    0 => 'East Caribbean dollar',
    1 => '951',
  ),
  'EGP' => 
  array (
    0 => 'Egyptian pound',
    1 => '818',
  ),
  'ETB' => 
  array (
    0 => 'Ethiopian birr',
    1 => '230',
  ),
  'EUR' => 
  array (
    0 => 'Euro',
    1 => '978',
  ),
  'FKP' => 
  array (
    0 => 'Falkland Islands pound',
    1 => '238',
  ),
  'FJD' => 
  array (
    0 => 'Fiji dollar',
    1 => '242',
  ),
  'HUF' => 
  array (
    0 => 'Forint',
    1 => '348',
  ),
  'CDF' => 
  array (
    0 => 'Franc Congolais',
    1 => '976',
  ),
  'GIP' => 
  array (
    0 => 'Gibraltar pound',
    1 => '292',
  ),
  'PYG' => 
  array (
    0 => 'Guarani',
    1 => '600',
  ),
  'GNF' => 
  array (
    0 => 'Guinea franc',
    1 => '324',
  ),
  'GYD' => 
  array (
    0 => 'Guyana dollar',
    1 => '328',
  ),
  'HTG' => 
  array (
    0 => 'Haiti gourde',
    1 => '332',
  ),
  'HKD' => 
  array (
    0 => 'Hong Kong dollar',
    1 => '344',
  ),
  'UAH' => 
  array (
    0 => 'Hryvnia',
    1 => '980',
  ),
  'ISK' => 
  array (
    0 => 'Iceland krona',
    1 => '352',
  ),
  'INR' => 
  array (
    0 => 'Indian rupee',
    1 => '356',
  ),
  'IRR' => 
  array (
    0 => 'Iranian rial',
    1 => '364',
  ),
  'IQD' => 
  array (
    0 => 'Iraqi dinar',
    1 => '368',
  ),
  'JMD' => 
  array (
    0 => 'Jamaican dollar',
    1 => '388',
  ),
  'JPY' => 
  array (
    0 => 'Japanese yen',
    1 => '392',
  ),
  'JOD' => 
  array (
    0 => 'Jordanian dinar',
    1 => '400',
  ),
  'KES' => 
  array (
    0 => 'Kenyan shilling',
    1 => '404',
  ),
  'PGK' => 
  array (
    0 => 'Kina',
    1 => '598',
  ),
  'LAK' => 
  array (
    0 => 'Kip',
    1 => '418',
  ),
  'EEK' => 
  array (
    0 => 'Kroon',
    1 => '233',
  ),
  'KWD' => 
  array (
    0 => 'Kuwaiti dinar',
    1 => '414',
  ),
  'MWK' => 
  array (
    0 => 'Kwacha',
    1 => '454',
  ),
  'ZMK' => 
  array (
    0 => 'Kwacha',
    1 => '894',
  ),
  'AOA' => 
  array (
    0 => 'Kwanza',
    1 => '973',
  ),
  'MMK' => 
  array (
    0 => 'Kyat',
    1 => '104',
  ),
  'GEL' => 
  array (
    0 => 'Lari',
    1 => '981',
  ),
  'LVL' => 
  array (
    0 => 'Latvian lats',
    1 => '428',
  ),
  'LBP' => 
  array (
    0 => 'Lebanese pound',
    1 => '422',
  ),
  'ALL' => 
  array (
    0 => 'Lek',
    1 => '008',
  ),
  'HNL' => 
  array (
    0 => 'Lempira',
    1 => '340',
  ),
  'SLL' => 
  array (
    0 => 'Leone',
    1 => '694',
  ),
  'LRD' => 
  array (
    0 => 'Liberian dollar',
    1 => '430',
  ),
  'LYD' => 
  array (
    0 => 'Libyan dinar',
    1 => '434',
  ),
  'SZL' => 
  array (
    0 => 'Lilangeni',
    1 => '748',
  ),
  'LTL' => 
  array (
    0 => 'Lithuanian litas',
    1 => '440',
  ),
  'LSL' => 
  array (
    0 => 'Loti',
    1 => '426',
  ),
  'MGA' => 
  array (
    0 => 'Malagasy ariary',
    1 => '969',
  ),
  'MYR' => 
  array (
    0 => 'Malaysian ringgit',
    1 => '458',
  ),
  'TMM' => 
  array (
    0 => 'Manat',
    1 => '795',
  ),
  'MUR' => 
  array (
    0 => 'Mauritius rupee',
    1 => '480',
  ),
  'MZN' => 
  array (
    0 => 'Metical',
    1 => '943',
  ),
  'MXN' => 
  array (
    0 => 'Mexican peso',
    1 => '484',
  ),
  'MDL' => 
  array (
    0 => 'Moldovan leu',
    1 => '498',
  ),
  'MAD' => 
  array (
    0 => 'Moroccan dirham',
    1 => '504',
  ),
  'NGN' => 
  array (
    0 => 'Naira',
    1 => '566',
  ),
  'ERN' => 
  array (
    0 => 'Nakfa',
    1 => '232',
  ),
  'NAD' => 
  array (
    0 => 'Namibian dollar',
    1 => '516',
  ),
  'NPR' => 
  array (
    0 => 'Nepalese rupee',
    1 => '524',
  ),
  'ANG' => 
  array (
    0 => 'Netherlands Antillean guilder',
    1 => '532',
  ),
  'ILS' => 
  array (
    0 => 'New Israeli shekel',
    1 => '376',
  ),
  'TWD' => 
  array (
    0 => 'New Taiwan dollar',
    1 => '901',
  ),
  'TRY' => 
  array (
    0 => 'New Turkish lira',
    1 => '949',
  ),
  'NZD' => 
  array (
    0 => 'New Zealand dollar',
    1 => '554',
  ),
  'BTN' => 
  array (
    0 => 'Ngultrum',
    1 => '064',
  ),
  'KPW' => 
  array (
    0 => 'North Korean won',
    1 => '408',
  ),
  'NOK' => 
  array (
    0 => 'Norwegian krone',
    1 => '578',
  ),
  'PEN' => 
  array (
    0 => 'Nuevo sol',
    1 => '604',
  ),
  'MRO' => 
  array (
    0 => 'Ouguiya',
    1 => '478',
  ),
  'TOP' => 
  array (
    0 => 'Pa\'anga',
    1 => '776',
  ),
  'PKR' => 
  array (
    0 => 'Pakistan rupee',
    1 => '586',
  ),
  'MOP' => 
  array (
    0 => 'Pataca',
    1 => '446',
  ),
  'UYU' => 
  array (
    0 => 'Peso Uruguayo',
    1 => '858',
  ),
  'PHP' => 
  array (
    0 => 'Philippine peso',
    1 => '608',
  ),
  'GBP' => 
  array (
    0 => 'Pound sterling',
    1 => '826',
  ),
  'BWP' => 
  array (
    0 => 'Pula',
    1 => '072',
  ),
  'QAR' => 
  array (
    0 => 'Qatari rial',
    1 => '634',
  ),
  'GTQ' => 
  array (
    0 => 'Quetzal',
    1 => '320',
  ),
  'CNY' => 
  array (
    0 => 'Renminbi',
    1 => '156',
  ),
  'OMR' => 
  array (
    0 => 'Rial Omani',
    1 => '512',
  ),
  'KHR' => 
  array (
    0 => 'Riel',
    1 => '116',
  ),
  'RON' => 
  array (
    0 => 'Romanian new leu',
    1 => '946',
  ),
  'MVR' => 
  array (
    0 => 'Rufiyaa',
    1 => '462',
  ),
  'IDR' => 
  array (
    0 => 'Rupiah',
    1 => '360',
  ),
  'RUB' => 
  array (
    0 => 'Russian ruble',
    1 => '643',
  ),
  'RWF' => 
  array (
    0 => 'Rwanda franc',
    1 => '646',
  ),
  'SHP' => 
  array (
    0 => 'Saint Helena pound',
    1 => '654',
  ),
  'WST' => 
  array (
    0 => 'Samoan tala',
    1 => '882',
  ),
  'SAR' => 
  array (
    0 => 'Saudi riyal',
    1 => '682',
  ),
  'RSD' => 
  array (
    0 => 'Serbian dinar',
    1 => '941',
  ),
  'SCR' => 
  array (
    0 => 'Seychelles rupee',
    1 => '690',
  ),
  'SGD' => 
  array (
    0 => 'Singapore dollar',
    1 => '702',
  ),
  'SKK' => 
  array (
    0 => 'Slovak koruna',
    1 => '703',
  ),
  'SBD' => 
  array (
    0 => 'Solomon Islands dollar',
    1 => '090',
  ),
  'KGS' => 
  array (
    0 => 'Som',
    1 => '417',
  ),
  'SOS' => 
  array (
    0 => 'Somali shilling',
    1 => '706',
  ),
  'TJS' => 
  array (
    0 => 'Somoni',
    1 => '972',
  ),
  'ZAR' => 
  array (
    0 => 'South African rand',
    1 => '710',
  ),
  'KRW' => 
  array (
    0 => 'South Korean won',
    1 => '410',
  ),
  'XDR' => 
  array (
    0 => 'Special Drawing Rights',
    1 => '960',
  ),
  'LKR' => 
  array (
    0 => 'Sri Lanka rupee',
    1 => '144',
  ),
  'SDG' => 
  array (
    0 => 'Sudanese pound',
    1 => '938',
  ),
  'SRD' => 
  array (
    0 => 'Surinam dollar',
    1 => '968',
  ),
  'SEK' => 
  array (
    0 => 'Swedish krona',
    1 => '752',
  ),
  'CHF' => 
  array (
    0 => 'Swiss franc',
    1 => '756',
  ),
  'SYP' => 
  array (
    0 => 'Syrian pound',
    1 => '760',
  ),
  'TZS' => 
  array (
    0 => 'Tanzanian shilling',
    1 => '834',
  ),
  'KZT' => 
  array (
    0 => 'Tenge',
    1 => '398',
  ),
  'TTD' => 
  array (
    0 => 'Trinidad and Tobago dollar',
    1 => '780',
  ),
  'MNT' => 
  array (
    0 => 'Tugrik',
    1 => '496',
  ),
  'TND' => 
  array (
    0 => 'Tunisian dinar',
    1 => '788',
  ),
  'USD' => 
  array (
    0 => 'US dollar',
    1 => '840',
  ),
  'UGX' => 
  array (
    0 => 'Uganda shilling',
    1 => '800',
  ),
  'COU' => 
  array (
    0 => 'Unidad de Valor Real',
    1 => '970',
  ),
  'AED' => 
  array (
    0 => 'United Arab Emirates dirham',
    1 => '784',
  ),
  'UZS' => 
  array (
    0 => 'Uzbekistan som',
    1 => '860',
  ),
  'VUV' => 
  array (
    0 => 'Vatu',
    1 => '548',
  ),
  'VEF' => 
  array (
    0 => 'Venezuelan bolívar fuerte',
    1 => '937',
  ),
  'VND' => 
  array (
    0 => 'Vietnamese đồng',
    1 => '704',
  ),
  'YER' => 
  array (
    0 => 'Yemeni rial',
    1 => '886',
  ),
  'ZWD' => 
  array (
    0 => 'Zimbabwe dollar',
    1 => '716',
  ),
  'PLN' => 
  array (
    0 => 'Zloty',
    1 => '985',
  ),
); ?>