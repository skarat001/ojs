<?php return array (
  'plugins.reports.articles.displayName' => 'Articles Report',
  'plugins.reports.articles.description' => 'This plugin implements a CSV report containing a list of articles and their info.',
  'plugins.reports.articles.nodecision' => 'No Decision',
); ?>