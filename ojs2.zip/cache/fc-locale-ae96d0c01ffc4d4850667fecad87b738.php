<?php return array (
  'plugins.reports.counter.jr1.title' => 'Journal Report 1',
); ?>