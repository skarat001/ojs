<?php return array (
  'plugins.block.readingTools.displayName' => 'Reading Tools Block',
  'plugins.block.readingTools.description' => 'This plugin displays a block containing reading tools in the reading tools sidebar.',
  'plugins.block.readingTools.title' => 'Reading tools',
  'plugins.block.readingTools.aboutTheAuthor' => 'About The Author',
  'plugins.block.readingTools.aboutTheAuthors' => 'About The Authors',
  'plugins.block.readingTools.articleTools' => 'Article Tools',
  'plugins.block.readingTools.emailThisArticle' => 'Email this article',
  'plugins.block.readingTools.loginRequired' => 'Login required',
  'plugins.block.readingTools.printThisArticle' => 'Print this article',
  'plugins.block.readingTools.postComment' => 'Post a Comment',
); ?>