<?php return array (
  'plugins.generic.usageEvent.displayName' => 'Usage event',
  'plugins.generic.usageEvent.description' => 'Creates a hook that provides usage event in a defined format.',
); ?>