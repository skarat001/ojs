<?php return array (
  'plugins.oaiMetadata.dc.displayName' => 'DC Metadata Format',
  'plugins.oaiMetadata.dc.description' => 'Structures metadata in a way that is consistent with the Dublin Core format.',
); ?>