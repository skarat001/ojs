<?php return array (
  'plugins.gateways.resolver.displayName' => 'Resolver Plugin',
  'plugins.gateways.resolver.description' => 'This plugin resolves issues and articles based on citation information.',
  'plugins.gateways.resolver.errors.errorMessage' => 'Unable to resolve a single entity using the specified citation information. Please ensure that the citation information is comprehensive and refers to an entity in this deployment of OJS.',
  'plugins.gateways.resolver.exportHoldings' => 'Export Holdings',
); ?>