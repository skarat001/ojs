<?php return array (
  'plugins.generic.webfeed.displayName' => 'Plugin Feed Web',
  'plugins.generic.webfeed.description' => 'Plugin ini menghasilkan RSS/ Atom web syndication feeds untuk terbitan sekarang.',
  'plugins.generic.webfeed.settings' => 'Pengaturan',
  'plugins.generic.webfeed.settings.issue' => 'Tampilkan link feed web hanya di halaman terbitan.',
  'plugins.generic.webfeed.settings.homepage' => 'Tampilkan link feed web hanya di homepage dan halaman terbitan.',
  'plugins.generic.webfeed.settings.all' => 'Tampilkan link feed web di seluruh halaman jurnal.',
  'plugins.generic.webfeed.settings.currentIssue' => 'Tampilkan item di terbitan yang diterbitkan sekarang.',
  'plugins.generic.webfeed.settings.recentArticles' => 'item yang diterbitkan sekarang.',
  'plugins.generic.webfeed.settings.recentItemsRequired' => 'Masukkan bilnagan bulat positif untuk item yang diterbitkan sekarang.',
  'plugins.generic.webfeed.atom.altText' => 'Logo atom',
  'plugins.generic.webfeed.rss1.altText' => 'Logo RSS1',
  'plugins.generic.webfeed.rss2.altText' => 'Logo RSS2',
); ?>