<?php return array (
  'plugins.reports.views.displayName' => 'Lihat Laporan',
  'plugins.reports.views.description' => 'Plugin ini mengimplementasikan laporan CSV yang menggambarkan kepembacaan untuk tiap artikel.',
); ?>