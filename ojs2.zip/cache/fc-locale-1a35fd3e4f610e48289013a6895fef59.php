<?php return array (
  'plugins.citationFormats.turabian.displayName' => 'Turabian citation format plugin',
  'plugins.citationFormats.turabian.citationFormatName' => 'Turabian',
  'plugins.citationFormats.turabian.description' => 'This plugin implements the Turabian citation format.',
); ?>