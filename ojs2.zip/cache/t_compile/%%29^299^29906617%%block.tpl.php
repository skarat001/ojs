<?php /* Smarty version 2.6.26, created on 2016-06-12 05:10:32
         compiled from file:C:%5Cxampp%5Chtdocs%5Cojs2%5Cojs-navbar-bawah%5Cojs/plugins/blocks/developedBy/block.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'translate', 'file:C:\\xampp\\htdocs\\ojs2\\ojs-navbar-bawah\\ojs/plugins/blocks/developedBy/block.tpl', 12, false),)), $this); ?>
<div class="block" id="sidebarDevelopedBy">
	<a class="blockTitle" href="http://pkp.sfu.ca/ojs/" id="developedBy"><?php echo $this->_plugins['function']['translate'][0][0]->smartyTranslate(array('key' => "common.openJournalSystems"), $this);?>
</a>
</div>