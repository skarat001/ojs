<?php /* Smarty version 2.6.26, created on 2016-06-14 04:51:40
         compiled from help/footer.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'call_hook', 'help/footer.tpl', 11, false),)), $this); ?>
<?php echo $this->_plugins['function']['call_hook'][0][0]->smartyCallHook(array('name' => "Templates::Help::Footer::PageFooter"), $this);?>

</div>
</div>
</body>
</html>
