<?php /* Smarty version 2.6.26, created on 2016-06-12 05:10:32
         compiled from common/minifiedScripts.tpl */ ?>


<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/lib/pkp/js/lib/jquery/plugins/jquery.tag-it.js"></script>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/lib/pkp/js/lib/jquery/plugins/jquery.cookie.js"></script>

<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/lib/pkp/js/functions/fontController.js"></script>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/lib/pkp/js/functions/general.js"></script>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/lib/pkp/js/functions/jqueryValidatorI18n.js"></script>

<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/lib/pkp/js/classes/Helper.js"></script>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/lib/pkp/js/classes/ObjectProxy.js"></script>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/lib/pkp/js/classes/Handler.js"></script>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/lib/pkp/js/classes/linkAction/LinkActionRequest.js"></script>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/lib/pkp/js/classes/features/Feature.js"></script>

<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/lib/pkp/js/controllers/SiteHandler.js"></script><!-- Included only for namespace definition -->
<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/lib/pkp/js/controllers/UrlInDivHandler.js"></script>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/lib/pkp/js/controllers/AutocompleteHandler.js"></script>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/lib/pkp/js/controllers/ExtrasOnDemandHandler.js"></script>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/lib/pkp/js/controllers/form/FormHandler.js"></script>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/lib/pkp/js/controllers/form/AjaxFormHandler.js"></script>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/lib/pkp/js/controllers/form/ClientFormHandler.js"></script>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/lib/pkp/js/controllers/grid/GridHandler.js"></script>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/lib/pkp/js/controllers/linkAction/LinkActionHandler.js"></script>

<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/js/pages/search/SearchFormHandler.js"></script>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/js/statistics/ReportGeneratorFormHandler.js"></script>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/plugins/generic/lucene/js/LuceneAutocompleteHandler.js"></script>

<script type="text/javascript" src="<?php echo $this->_tpl_vars['baseUrl']; ?>
/lib/pkp/js/lib/jquery/plugins/jquery.pkp.js"></script>

