<?php /* Smarty version 2.6.26, created on 2016-06-13 14:38:14
         compiled from user/login.tpl */ ?>
<?php echo ''; ?><?php $this->assign('helpTopicId', "user.registerAndProfile"); ?><?php echo ''; ?><?php $this->assign('registerOp', 'register'); ?><?php echo ''; ?><?php $this->assign('registerLocaleKey', "user.login.registerNewAccount"); ?><?php echo ''; ?><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "core:user/login.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?><?php echo ''; ?>

