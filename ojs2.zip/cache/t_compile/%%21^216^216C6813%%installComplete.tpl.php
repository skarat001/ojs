<?php /* Smarty version 2.6.26, created on 2016-06-09 06:00:51
         compiled from install/installComplete.tpl */ ?>
<?php echo ''; ?><?php $this->assign('pageTitle', "installer.ojsInstallation"); ?><?php echo ''; ?><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "core:install/installComplete.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?><?php echo ''; ?>
