<?php return array (
  'manualInstructions' => 'transfer ke BCA 100 1992 2913',
); ?>