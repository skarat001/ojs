<?php return array (
  'plugins.block.authorBios.displayName' => 'Author biography Block',
  'plugins.block.authorBios.description' => 'This plugin displays a block containing author biographies in the reading tools sidebar.',
  'plugins.block.authorBios.title' => 'About The Authors',
  'plugins.block.authorBios.aboutTheAuthor' => 'About The Author',
  'plugins.block.authorBios.aboutTheAuthors' => 'About The Authors',
); ?>