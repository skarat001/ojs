<?php return array (
  'plugins.citationFormats.refMan.displayName' => 'Reference Manager citation format plugin',
  'plugins.citationFormats.refMan.citationFormatName' => 'Reference Manager - RIS format (Windows only)',
  'plugins.citationFormats.refMan.description' => 'This plugin implements the Reference Manager citation format.',
); ?>