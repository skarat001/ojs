<?php return array (
  'plugins.metadata.mods34.articleAdapter.displayName' => 'MODS 3.4 Article Adapter',
  'plugins.metadata.mods34.articleAdapter.description' => 'Extracts/injects meta-data from/into articles.',
); ?>