<?php return array (
  'plugins.block.donation.displayName' => 'Donation Block',
  'plugins.block.donation.description' => 'This plugin provides a sidebar link for accepting donations.',
); ?>