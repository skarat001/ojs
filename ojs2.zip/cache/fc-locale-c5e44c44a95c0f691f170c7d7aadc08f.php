<?php return array (
  'plugins.importexport.crossref.displayName' => 'Plugin Ekspor CrossRef XML',
  'plugins.importexport.crossref.description' => '> ekspor metadata artikel di format CrossRef XML.',
  'plugins.importexport.crossref.cliUsage' => 'Kegunaan: 
{$scriptName} {$pluginName} [xmlFileName] [journal_path] articles [articleId1] [articleId2] ...
{$scriptName} {$pluginName} [xmlFileName] [journal_path] issue [issueId]',
); ?>