<?php return array (
  'plugins.OAIMetadata.marcxml.displayName' => 'MARC21 Metadata Format',
  'plugins.OAIMetadata.marcxml.description' => 'Structures metadata in a way that is consistent with the MARC21 format.',
); ?>