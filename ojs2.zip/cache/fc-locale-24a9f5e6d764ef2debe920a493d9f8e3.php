<?php return array (
  'plugins.block.keywordCloud.displayName' => 'Blok Kata Kunci Cloud',
  'plugins.block.keywordCloud.description' => 'Plugin ini menyediakan tag cloud dari kanta kunci artikel.',
  'plugins.block.keywordCloud.title' => 'Kata Kunci',
); ?>