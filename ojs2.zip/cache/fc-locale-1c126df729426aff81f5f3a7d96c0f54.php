<?php return array (
  'plugins.citationOutput.vancouver.displayName' => 'Vancouver Citation Style',
  'plugins.citationOutput.vancouver.description' => 'Implements the Vancouver citation style.',
); ?>