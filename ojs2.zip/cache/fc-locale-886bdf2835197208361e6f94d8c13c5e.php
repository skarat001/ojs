<?php return array (
  'plugins.theme.custom.name' => 'Custom Theme Plugin',
  'plugins.theme.custom.description' => 'This plugin implements a customizeable theme.',
  'plugins.theme.custom.notWritable' => 'NOTE: This plugin\'s stylesheet file, "{$stylesheetFileLocation}", is not currently writable. This file must be writable before the plugin can be used.',
  'plugins.theme.custom.notWritablePlugin' => 'NOTE: The journal-based stylesheet option is automatically enabled because this plugin\'s stylesheet file, "{$stylesheetFileLocation}", is not currently writable.',
  'plugins.theme.custom.settings' => 'Settings',
  'plugins.theme.custom.pickColour' => 'Pick Colour',
  'plugins.theme.custom.header' => 'Header',
  'plugins.theme.custom.link' => 'Link',
  'plugins.theme.custom.background' => 'Background',
  'plugins.theme.custom.foreground' => 'Foreground',
  'plugins.theme.custom.perJournal' => 'Journal-based Stylesheet',
); ?>