<?php return array (
  'plugins.generic.acron.name' => 'Acron Plugin',
  'plugins.generic.acron.description' => 'This plugin attempts to reduce the dependance of OJS on periodic scheduling tools such as \'cron.\'',
  'plugins.generic.acron.enabled' => 'The Acron Plugin has been enabled.',
  'plugins.generic.acron.disabled' => 'The Acron Plugin has been disabled.',
  'plugins.generic.acron.reload' => 'Reload Scheduled Tasks',
); ?>