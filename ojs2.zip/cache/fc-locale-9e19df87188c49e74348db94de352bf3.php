<?php return array (
  'plugins.block.navigation.displayName' => 'Navigation Block',
  'plugins.block.navigation.description' => 'This plugin provides sidebar navigation links.',
  'plugins.block.navigation.journalContent' => 'Journal Content',
  'plugins.block.navigation.searchScope' => 'Search Scope',
); ?>