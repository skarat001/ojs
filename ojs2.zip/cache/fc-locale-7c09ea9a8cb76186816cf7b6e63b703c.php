<?php return array (
  'plugins.citationOutput.apa.displayName' => 'APA Citation Style',
  'plugins.citationOutput.apa.description' => 'Implements the APA citation style.',
); ?>