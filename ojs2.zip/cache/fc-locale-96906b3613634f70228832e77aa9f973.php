<?php return array (
  'plugins.reports.counter.ar1.title' => 'Article Report 1',
); ?>