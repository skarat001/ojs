<?php return array (
  'plugins.block.role.displayName' => 'Blok Spesifikasi Peran',
  'plugins.block.role.description' => 'Plugin ini menyediakan blok yang berisi informasi spesifikasi peran seperti perhitungan penyerahan dan link untuk Editor, Penulis, dll.',
); ?>