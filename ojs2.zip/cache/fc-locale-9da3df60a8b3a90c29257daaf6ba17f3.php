<?php return array (
  'plugins.oaiMetadata.nlm.displayName' => 'NLM Metadata Format',
  'plugins.oaiMetadata.nlm.description' => 'Structures metadata in a way that is consistent with the NLM Journal Article format.',
); ?>