<?php return array (
  'plugins.citationOutput.mla.displayName' => 'MLA Citation Style',
  'plugins.citationOutput.mla.description' => 'Implements the MLA citation style.',
); ?>