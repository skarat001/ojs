<?php return array (
  'plugins.citationFormats.proCite.displayName' => 'ProCite citation format plugin',
  'plugins.citationFormats.proCite.citationFormatName' => 'ProCite - RIS format (Macintosh & Windows)',
  'plugins.citationFormats.proCite.description' => 'This plugin implements the ProCite citation format.',
); ?>