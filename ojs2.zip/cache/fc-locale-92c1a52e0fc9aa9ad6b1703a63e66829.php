<?php return array (
  'plugins.block.navigation.displayName' => 'Blok Navigasi',
  'plugins.block.navigation.description' => 'Plugin ini menyediakan link navigasi.',
  'plugins.block.navigation.journalContent' => 'Isi Jurnal',
); ?>