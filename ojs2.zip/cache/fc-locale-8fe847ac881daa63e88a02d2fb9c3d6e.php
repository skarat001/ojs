<?php return array (
  'plugins.citationParser.paracite.displayName' => 'ParaCite Citation Extractor',
  'plugins.citationParser.paracite.description' => 'Extracts fields from plain text citations via the ParaCite service.',
); ?>