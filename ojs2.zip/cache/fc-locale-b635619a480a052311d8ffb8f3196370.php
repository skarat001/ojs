<?php return array (
  'plugins.block.relatedItems.displayName' => 'Blok Item Terkait',
  'plugins.block.relatedItems.description' => 'Plugin ini menampilkan blok yang berisi item terkait di bagian alat membaca.',
  'plugins.block.relatedItems.title' => 'Item Terkait',
  'plugins.block.relatedItems.hide' => 'Sembunyikan',
  'plugins.block.relatedItems.show' => 'Tampilkan Semua',
); ?>