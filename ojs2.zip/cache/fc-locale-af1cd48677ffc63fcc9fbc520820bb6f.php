<?php return array (
  'plugins.block.fontSize.displayName' => 'Font Size Block',
  'plugins.block.fontSize.description' => 'This plugin provides sidebar font sizer.',
  'plugins.block.fontSize.title' => 'Font Size',
  'plugins.block.fontSize.small' => 'Small',
  'plugins.block.fontSize.medium' => 'Medium',
  'plugins.block.fontSize.large' => 'Large',
); ?>