<?php return array (
  'plugins.importexport.sample.displayName' => 'Sample Import/Export Plugin',
  'plugins.importexport.sample.description' => 'This plugin provides an implementation example to be used when developing import/export plugins. It\'s not very useful in and of itself.',
  'plugins.importexport.sample.selectIssue.short' => 'Select Issue',
  'plugins.importexport.sample.selectIssue.long' => 'Select an Issue to export.',
); ?>