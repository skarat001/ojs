<?php return array (
  'plugins.reports.reviews.displayName' => 'Review Report',
  'plugins.reports.reviews.description' => 'This plugin implements a CSV report containing a list of review assignments for a journal.',
  'plugins.reports.reviews.round' => 'Round',
  'plugins.reports.reviews.reviewerId' => 'Reviewer ID',
  'plugins.reports.reviews.reviewer' => 'Reviewer',
  'plugins.reports.reviews.dateAssigned' => 'Date Assigned',
  'plugins.reports.reviews.dateNotified' => 'Date Notified',
  'plugins.reports.reviews.dateConfirmed' => 'Date Confirmed',
  'plugins.reports.reviews.dateCompleted' => 'Date Completed',
  'plugins.reports.reviews.dateReminded' => 'Date Reminded',
); ?>