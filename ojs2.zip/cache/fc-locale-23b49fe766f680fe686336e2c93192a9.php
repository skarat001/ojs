<?php return array (
  'plugins.generic.announcementfeed.displayName' => 'Plugin Feed Pengumuman',
  'plugins.generic.announcementfeed.description' => 'Plugin ini menghasilkan RSS/ Atom web syndication feeds untuk pengumuman jurnal.',
  'plugins.generic.announcementfeed.settings' => 'Pengaturan',
  'plugins.generic.announcementfeed.settings.all' => 'Tampilkan link feed di seluruh halaman jurnal.',
  'plugins.generic.announcementfeed.settings.homepage' => 'Tampilkan link feed hanya di homepage dan halaman pengumuman.',
  'plugins.generic.announcementfeed.settings.announcement' => 'Tampilkan link feed hanya di halaman pengumuman.',
  'plugins.generic.announcementfeed.settings.recentAnnouncements1' => 'Batasi feed pada',
  'plugins.generic.announcementfeed.settings.recentAnnouncements2' => 'pengumuman baru-baru ini.',
  'plugins.generic.announcementfeed.settings.recentItemsRequired' => 'Masukkan bilangan bulat positif untuk pengumuman baru-baru ini.',
  'plugins.generic.announcementfeed.atom.altText' => 'Logo Atom',
  'plugins.generic.announcementfeed.rss1.altText' => 'Logo RSS1',
  'plugins.generic.announcementfeed.rss2.altText' => 'Logo RSS2',
); ?>