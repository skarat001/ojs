<?php return array (
  'topic' => 
  array (
    0 => 
    array (
      'attributes' => 
      array (
        'id' => 'user/topic/000005',
        'locale' => 'en_US',
        'title' => 'Search and Browse',
        'toc' => 'user/toc/000000',
        'key' => 'user.searchAndBrowse',
      ),
      'value' => '',
    ),
  ),
  'section' => 
  array (
    0 => 
    array (
      'attributes' => 
      array (
      ),
      'value' => '<p>The journal\'s contents can be searched by author, title, abstract, and index terms. The full text of the contents can be searched both in HTML and PDF file formats. Alternatively, using the Browse link in the right-hand margin of the page, readers can browse the contents of the journal by issue, author, and title. Other journals published through this installation of Open Journal Systems may also be browsed.</p>',
    ),
  ),
); ?>