<?php return array (
  'plugins.block.user.displayName' => 'Blok Pengguna',
  'plugins.block.user.description' => 'Plugin ini menyediakan alat untuk akun pengguna (contoh: login, logout, link profil, dll).',
  'plugins.block.user.loggedInAs' => 'Anda login sebagai...',
  'plugins.block.user.myJournals' => 'Jurnal Saya',
  'plugins.block.user.myProfile' => 'Profil Saya',
  'plugins.block.user.logout' => 'Log Out',
  'plugins.block.user.signOutAsUser' => 'Log Out sebagai Pengguna',
  'plugins.block.user.rememberMe' => 'Ingat Saya',
); ?>