<?php return array (
  'plugins.block.authorBios.displayName' => 'Blok Biografi Penulis',
  'plugins.block.authorBios.description' => 'Plugin ini menampilkan blok yang berisi biografi penulis dalam bagian alat membaca.',
  'plugins.block.authorBios.title' => 'Tentang Penulis',
  'plugins.block.authorBios.aboutTheAuthor' => 'Tentang Penulis',
  'plugins.block.authorBios.aboutTheAuthors' => 'Tentang Penulis',
); ?>