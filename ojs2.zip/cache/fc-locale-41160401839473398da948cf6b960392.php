<?php return array (
  'plugins.paymethod.manual.displayName' => 'Manual Fee Payment',
  'plugins.paymethod.manual.description' => 'The manager will manually record receipt of a user\'s payment (outside of this software).',
  'plugins.paymethod.manual' => 'Manual Fee Payment',
  'plugins.paymethod.manual.settings' => 'Manual Payment Settings',
  'plugins.paymethod.manual.settings.instructions' => 'Instructions',
  'plugins.paymethod.manual.settings.manualInstructions' => 'Fee Payment Instructions for users selecting manual fee payment',
  'plugins.paymethod.manual.sendNotificationOfPayment' => 'Send notification of payment',
  'plugins.paymethod.manual.paymentNotification' => 'Payment Notification',
  'plugins.paymethod.manual.notificationSent' => 'Payment notification sent',
  'plugins.paymethod.manual.purchase.title' => 'Title',
  'plugins.paymethod.manual.purchase.fee' => 'Fee',
); ?>