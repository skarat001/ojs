<?php return array (
  'plugins.block.help.displayName' => 'Blok Bantuan',
  'plugins.block.help.description' => 'Plugin ini menyediakan link bantuan.',
); ?>