<?php return array (
  'toc' => 
  array (
    0 => 
    array (
      'attributes' => 
      array (
        'id' => 'user/toc/000000',
        'locale' => 'en_US',
        'title' => 'Journal Web Site',
        'parent_topic' => 'user/topic/000000',
      ),
      'value' => '',
    ),
  ),
  'topic' => 
  array (
    0 => 
    array (
      'attributes' => 
      array (
        'id' => 'user/topic/000001',
        'title' => 'Home',
      ),
      'value' => '',
    ),
    1 => 
    array (
      'attributes' => 
      array (
        'id' => 'user/topic/000002',
        'title' => 'About',
      ),
      'value' => '',
    ),
    2 => 
    array (
      'attributes' => 
      array (
        'id' => 'user/topic/000007',
        'title' => 'User Home',
      ),
      'value' => '',
    ),
    3 => 
    array (
      'attributes' => 
      array (
        'id' => 'user/topic/000003',
        'title' => 'Register & Profile',
      ),
      'value' => '',
    ),
    4 => 
    array (
      'attributes' => 
      array (
        'id' => 'user/topic/000004',
        'title' => 'Current & Archives',
      ),
      'value' => '',
    ),
    5 => 
    array (
      'attributes' => 
      array (
        'id' => 'user/topic/000005',
        'title' => 'Search & Browse',
      ),
      'value' => '',
    ),
    6 => 
    array (
      'attributes' => 
      array (
        'id' => 'user/topic/000006',
        'title' => 'Reading Tools',
      ),
      'value' => '',
    ),
  ),
  'breadcrumb' => 
  array (
    0 => 
    array (
      'attributes' => 
      array (
        'url' => 'user/topic/000000',
        'title' => 'Journal Web Site',
      ),
      'value' => '',
    ),
  ),
); ?>