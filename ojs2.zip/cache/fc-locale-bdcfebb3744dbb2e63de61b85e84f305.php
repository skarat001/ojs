<?php return array (
  'plugins.citationFormats.mla.displayName' => 'MLA citation format plugin',
  'plugins.citationFormats.mla.citationFormatName' => 'MLA',
  'plugins.citationFormats.mla.description' => 'This plugin implements the MLA citation format.',
  'plugins.citationFormats.mla.noPages' => 'n. pag.',
); ?>