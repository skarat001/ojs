<?php return array (
  'plugins.citationFormats.bibtex.displayName' => 'BibTeX citation format plugin',
  'plugins.citationFormats.bibtex.citationFormatName' => 'BibTeX',
  'plugins.citationFormats.bibtex.description' => 'This plugin implements the BibTeX citation format.',
); ?>