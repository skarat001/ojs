<?php return array (
  'plugins.citationParser.parscit.displayName' => 'ParsCit Citation Extractor',
  'plugins.citationParser.parscit.description' => 'Extracts fields from plain text citations via the ParsCit service.',
); ?>