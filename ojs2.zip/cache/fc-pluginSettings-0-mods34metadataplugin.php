<?php return array (
  'metadataPluginControlledVocabInstalled' => true,
); ?>