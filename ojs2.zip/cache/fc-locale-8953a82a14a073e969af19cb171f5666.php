<?php return array (
  'plugins.block.relatedItems.displayName' => 'Related Items Block',
  'plugins.block.relatedItems.description' => 'This plugin displays a block containing related items in the reading tools sidebar.',
  'plugins.block.relatedItems.title' => 'Related Items',
  'plugins.block.relatedItems.hide' => 'Hide',
  'plugins.block.relatedItems.show' => 'Show all',
); ?>