<?php return array (
  'plugins.block.donation.displayName' => 'Blok Donasi',
  'plugins.block.donation.description' => 'Plugin ini menyediakan link untuk menerima donasi.',
); ?>