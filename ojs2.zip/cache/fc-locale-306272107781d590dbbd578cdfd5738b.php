<?php return array (
  'plugins.importexport.sample.displayName' => 'Contoh Plugin Impor/Ekspor',
  'plugins.importexport.sample.description' => 'Plugin ini menyediakan contoh implementasi untuk digunakan ketika membangun plugin Impor/Ekspor.',
  'plugins.importexport.sample.selectIssue.short' => 'Pilih Isu',
  'plugins.importexport.sample.selectIssue.long' => 'Plih isu untuk di ekspor.',
); ?>