<?php return array (
  'plugins.generic.phpmv.displayName' => 'Plugin phpMyVisites',
  'plugins.generic.phpmv.description' => 'Gabungkan OJS dengan phpMyVisites, aplikasi analis lalu lintas situs web sumber terbuka. Memerlukan phpMyVisites sudah diinstal. Lihat <a href="http://www.phpmyvisites.us/" title="phpMyVisites site">situs phpMyVisites</a> untuk informasi lebih lanjut.',
  'plugins.generic.phpmv.manager.settings' => 'Pengaturan',
  'plugins.generic.phpmv.manager.phpmvSettings' => 'Pengaturan phpMyVisites',
  'plugins.generic.phpmv.manager.settings.description' => '<p>Dengan plugin ini phpMyVisites dapat digunakan untuk mengoleksi dan menganalisa kegunaan dan lalu lintas web site untuk jurnal ini. Perhatikan plugin ini membutuhkan phpMyVisites sudah diinstal. Lihat  <a href="http://www.phpmyvisites.us/" title="phpMyVisites site">situs phpMyVisites</a> for more information.</p>',
  'plugins.generic.phpmv.manager.settings.phpmvUrl' => 'Url phpMyVisites',
  'plugins.generic.phpmv.manager.settings.phpmvUrlInstructions' => 'Url lengkao untuk instalasi phpMyVisites Anda (i.e. http://myserver.net/phpmv).',
  'plugins.generic.phpmv.manager.settings.phpmvUrlRequired' => 'Masukkan url valid. Termasuk  http:// saat mulai.',
  'plugins.generic.phpmv.manager.settings.phpmvSiteId' => 'Nomor profil situs',
  'plugins.generic.phpmv.manager.settings.phpmvSiteIdInstructions' => 'Di dalam phpMyVisites, klik di Administrasi->Modifikasi situs.  Nomor profil situs ditampilkan di sebelah nama profil situs Anda.',
  'plugins.generic.phpmv.manager.settings.phpmvSiteIdRequired' => 'Masukkan nomor profil situs.',
); ?>