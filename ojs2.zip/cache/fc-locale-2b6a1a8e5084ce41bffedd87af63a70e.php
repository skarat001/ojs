<?php return array (
  'plugins.block.fontSize.displayName' => 'Blok Ukuran Huruf',
  'plugins.block.fontSize.description' => 'Plugin ini menyediakan pengaturan ukuran huruf.',
  'plugins.block.fontSize.title' => 'Ukuran Huruf',
  'plugins.block.fontSize.small' => 'Kecil',
  'plugins.block.fontSize.medium' => 'Sedang',
  'plugins.block.fontSize.large' => 'Besar',
); ?>