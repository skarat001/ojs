<?php return array (
  'plugins.block.keywordCloud.displayName' => 'Keyword Cloud Block',
  'plugins.block.keywordCloud.description' => 'This plugin provides a tag cloud of article keywords.',
  'plugins.block.keywordCloud.title' => 'Keywords',
); ?>