<?php return array (
  'plugins.metadata.openurl10.displayName' => 'OpenURL 1.0 meta-data',
  'plugins.metadata.openurl10.description' => 'Contributes OpenURL 1.0 schemas and application adapters.',
); ?>