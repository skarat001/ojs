<?php return array (
  'plugins.citationLookup.crossref.displayName' => 'CrossRef Database Connector',
  'plugins.citationLookup.crossref.description' => 'Connects to the CrossRef bibliographic database.',
); ?>