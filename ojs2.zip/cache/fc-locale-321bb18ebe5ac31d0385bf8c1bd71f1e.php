<?php return array (
  'plugins.generic.roundedcorners.displayName' => 'Rounded Corners',
  'plugins.generic.roundedcorners.description' => 'This Plugin puts a background on each sidebar block and rounds its corners.  Changes can be made to the colours used by editing the CSS stylesheet found in the plugin.',
); ?>