<?php return array (
  'plugins.generic.thesisfeed.displayName' => 'Plugin Feed Abstrak Tesis',
  'plugins.generic.thesisfeed.description' => 'Plugin ini menghasilkan RSS/ Atom web syndication feeds untuk abstrak tesis.',
  'plugins.generic.thesisfeed.settings' => 'Pengaturan',
  'plugins.generic.thesisfeed.settings.all' => 'Tampilkan link feed di seluruh halaman jurnal.',
  'plugins.generic.thesisfeed.settings.homepage' => 'Tampilkan link feed hanya di homepage dan halaman abstrak tesis.',
  'plugins.generic.thesisfeed.settings.thesis' => 'Tampilkan link feed hanya di halaman abstrak tesis.',
  'plugins.generic.thesisfeed.settings.recentThesis1' => 'Batasi feed pada',
  'plugins.generic.thesisfeed.settings.recentThesis2' => 'abstrak tesis yang dikumpulkan baru-baru ini.',
  'plugins.generic.thesisfeed.settings.recentItemsRequired' => 'Masukkan bilangan bulat positif untuk nomor abstrak tesis.',
  'plugins.generic.thesisfeed.atom.altText' => 'Logo atom',
  'plugins.generic.thesisfeed.rss1.altText' => 'Logo RSS1',
  'plugins.generic.thesisfeed.rss2.altText' => 'Logo RSS2',
); ?>