<?php return array (
  'plugins.generic.tinymce.name' => 'Plugin TinyMCE',
  'plugins.generic.tinymce.description' => 'Plugin ini memudahkan pengeditan WYSIWYG untuk teks area OJS menggunakan <a href="http://tinymce.moxiecode.com" target="_new">TinyMCE</a> konten editor.',
  'plugins.generic.tinymce.descriptionDisabled' => 'Plugin ini memudahkan pengeditan WYSIWYG untuk teks area OJS menggunakan <a href="http://tinymce.moxiecode.com" target="_new">TinyMCE</a> konten editor. <strong>TinyMCE sekarang belum diinstal; mohon instal ini di {$tinyMcePath}.</strong>',
  'plugins.generic.tinymce.settings' => 'Pengaturan',
); ?>