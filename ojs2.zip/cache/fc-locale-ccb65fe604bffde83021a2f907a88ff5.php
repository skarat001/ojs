<?php return array (
  'plugins.block.notification.displayName' => 'Blok Notifikasi',
  'plugins.block.notification.description' => 'Plugin ini menampilkan informasi tentang notifikasi sistem.',
); ?>