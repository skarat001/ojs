<?php return array (
  'plugins.citationFormats.cbe.displayName' => 'CBE citation format plugin',
  'plugins.citationFormats.cbe.citationFormatName' => 'CBE',
  'plugins.citationFormats.cbe.description' => 'This plugin implements the CBE citation format.',
); ?>