<?php return array (
  'plugins.implicitAuth.shibboleth.displayName' => 'ShibAuthPlugin',
  'plugins.implicitAuth.shibboleth.description' => 'ShibAuthPlugin. This is a site-wide plugin and is enabled in the OJS config file.',
); ?>