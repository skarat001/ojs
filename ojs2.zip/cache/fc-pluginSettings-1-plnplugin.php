<?php return array (
  'checksum_type' => 'SHA-1',
  'enabled' => false,
  'journal_uuid' => '',
  'object_threshold' => 20,
  'object_type' => 'Issue',
  'pln_accepting' => false,
); ?>